<?php
/**
 * Post & Video Deep Link Landing Page
 * Opens Flikata App if installed or displays post preview
 */

require_once __DIR__ . '/config/db.php';
$pdo = getDB();

$postId = (int)($_GET['id'] ?? $_GET['post_id'] ?? 0);
$reelId = (int)($_GET['reel_id'] ?? 0);

$title = "Flikata - Social Network";
$content = "Check out this update on Flikata!";
$author = "Flikata User";
$imageUrl = "";
$videoUrl = "";
$deepLink = "flikata://home";

if ($postId) {
    $stmt = $pdo->prepare("SELECT p.*, u.full_name, u.profile_pic FROM posts p JOIN users u ON p.user_id = u.id WHERE p.id = ?");
    $stmt->execute([$postId]);
    $post = $stmt->fetch();
    if ($post) {
        $author = $post['full_name'];
        $content = $post['content'] ?: "Post by " . $author;
        $title = $author . " on Flikata: \"" . mb_strimwidth($content, 0, 60, "...") . "\"";
        $imageUrl = $post['image_url'] ?: $post['profile_pic'];
        $videoUrl = $post['video_url'];
        $deepLink = "flikata://post/" . $postId;
    }
} elseif ($reelId) {
    $stmt = $pdo->prepare("SELECT r.*, u.full_name, u.profile_pic FROM reels r JOIN users u ON r.user_id = u.id WHERE r.id = ?");
    $stmt->execute([$reelId]);
    $reel = $stmt->fetch();
    if ($reel) {
        $author = $reel['full_name'];
        $content = $reel['caption'] ?: "Reel by " . $author;
        $title = $author . "'s Reel on Flikata";
        $videoUrl = $reel['media_url'];
        $deepLink = "flikata://reel/" . $reelId;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($title) ?></title>
    <!-- Open Graph for Facebook, WhatsApp, Messenger -->
    <meta property="og:title" content="<?= htmlspecialchars($title) ?>" />
    <meta property="og:description" content="<?= htmlspecialchars($content) ?>" />
    <?php if ($imageUrl): ?>
    <meta property="og:image" content="<?= htmlspecialchars($imageUrl) ?>" />
    <?php endif; ?>
    <?php if ($videoUrl): ?>
    <meta property="og:video" content="<?= htmlspecialchars($videoUrl) ?>" />
    <meta property="og:type" content="video.other" />
    <?php else: ?>
    <meta property="og:type" content="article" />
    <?php endif; ?>
    <meta property="og:site_name" content="Flikata" />

    <style>
        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
            background: #f0f2f5;
            color: #1c1e21;
            margin: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            min-height: 100vh;
            padding: 16px;
            box-sizing: border-box;
        }
        .card {
            background: #ffffff;
            border-radius: 16px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
            max-width: 480px;
            width: 100%;
            overflow: hidden;
            text-align: center;
            padding: 24px;
        }
        .logo {
            font-size: 28px;
            font-weight: 800;
            color: #1877F2;
            letter-spacing: -0.5px;
            margin-bottom: 20px;
        }
        .author {
            font-size: 16px;
            font-weight: 700;
            color: #050505;
            margin-bottom: 6px;
        }
        .content {
            font-size: 14px;
            color: #65676B;
            line-height: 1.5;
            margin-bottom: 18px;
            word-break: break-word;
        }
        .media {
            width: 100%;
            max-height: 340px;
            object-fit: cover;
            border-radius: 12px;
            margin-bottom: 20px;
        }
        .btn {
            display: inline-block;
            background: #1877F2;
            color: #ffffff;
            text-decoration: none;
            padding: 14px 28px;
            border-radius: 24px;
            font-weight: 700;
            font-size: 15px;
            box-shadow: 0 4px 12px rgba(24, 119, 242, 0.3);
            transition: background 0.2s;
            width: calc(100% - 56px);
        }
        .btn:hover {
            background: #166fe5;
        }
    </style>
</head>
<body>
    <div class="card">
        <div class="logo">Flikata</div>
        <div class="author"><?= htmlspecialchars($author) ?></div>
        <div class="content"><?= nl2br(htmlspecialchars($content)) ?></div>
        <?php if ($videoUrl): ?>
            <video class="media" controls src="<?= htmlspecialchars($videoUrl) ?>"></video>
        <?php elseif ($imageUrl): ?>
            <img class="media" src="<?= htmlspecialchars($imageUrl) ?>" alt="Post Image" />
        <?php endif; ?>
        <div>
            <a href="<?= htmlspecialchars($deepLink) ?>" class="btn">Open in Flikata App</a>
        </div>
    </div>

    <script>
        // Automatically attempt to open in Flikata app if on mobile
        window.location.href = "<?= $deepLink ?>";
    </script>
</body>
</html>
