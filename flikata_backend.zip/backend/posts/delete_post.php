<?php
/**
 * Delete Post Endpoint
 * Flikata API
 */

require_once __DIR__ . '/../config/db.php';
$pdo = getDB();

$input = json_decode(file_get_contents('php://input'), true) ?: $_POST;

$user = getAuthUser($pdo);
if (!$user && !empty($input['user_id'])) {
    $uStmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $uStmt->execute([$input['user_id']]);
    $user = $uStmt->fetch() ?: null;
}

if (!$user) {
    jsonResponse(false, null, 'Authentication required.');
}

$postId = (int)($input['post_id'] ?? 0);

if (!$postId) {
    jsonResponse(false, null, 'Invalid post ID.');
}

// Ensure the user owns the post
$stmt = $pdo->prepare("SELECT id FROM posts WHERE id = ? AND user_id = ?");
$stmt->execute([$postId, $user['id']]);
if (!$stmt->fetch()) {
    jsonResponse(false, null, 'You do not have permission to delete this post.');
}

$del = $pdo->prepare("DELETE FROM posts WHERE id = ?");
$del->execute([$postId]);

jsonResponse(true, null, 'Post deleted successfully.');
